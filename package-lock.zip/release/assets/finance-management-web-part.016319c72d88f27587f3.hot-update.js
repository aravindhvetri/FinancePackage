"use strict";
self["webpackHotUpdate_4b0442cb_663c_407a_af12_58b560148ae9_0_0_1"]("finance-management-web-part",{

/***/ 3336:
/*!***********************************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/MainComponents/MainComponent.js ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ExternalRef_CSS_Style_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../ExternalRef/CSS/Style.css */ 6051);
/* harmony import */ var _NavBar_NavBar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../NavBar/NavBar */ 1913);



var MainComponent = function (props) {
    return react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_NavBar_NavBar__WEBPACK_IMPORTED_MODULE_2__["default"], { context: props.context })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainComponent);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("5691a51b8eaf7bfe661b")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=finance-management-web-part.016319c72d88f27587f3.hot-update.js.map