"use strict";
self["webpackHotUpdate_4b0442cb_663c_407a_af12_58b560148ae9_0_0_1"]("finance-management-web-part",{

/***/ 2784:
/*!**************************************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBarStyle.module.scss.css ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 6323);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".sidebar_e7df71e0{background:#f4f5f7;font-family:Segoe UI,sans-serif;height:100vh;padding:20px 10px;width:250px}.menuItem_e7df71e0{align-items:center;border-radius:8px;cursor:pointer;display:flex;justify-content:space-between;margin-bottom:6px;padding:10px 14px;transition:.2s ease}.menuItem_e7df71e0:hover{background:#e6e7eb}.menuLeft_e7df71e0{align-items:center;display:flex;gap:10px}.icon_e7df71e0{font-size:14px}.chevron_e7df71e0{font-size:12px}.subMenu_e7df71e0{border-left:1px solid #ddd;margin-left:20px;padding-left:15px}.subItem_e7df71e0{align-items:center;border-radius:6px;cursor:pointer;display:flex;gap:8px;margin-bottom:4px;padding:8px 10px}.subItem_e7df71e0:hover{background:#e6e7eb}.active_e7df71e0{background:3f9f4e;font-weight:500}", true);

// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  sidebar: "sidebar_e7df71e0",
  menuItem: "menuItem_e7df71e0",
  menuLeft: "menuLeft_e7df71e0",
  icon: "icon_e7df71e0",
  chevron: "chevron_e7df71e0",
  subMenu: "subMenu_e7df71e0",
  subItem: "subItem_e7df71e0",
  active: "active_e7df71e0"
});


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("e692b6b144e61f963dc0")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=finance-management-web-part.06ce3507d2de37a19412.hot-update.js.map