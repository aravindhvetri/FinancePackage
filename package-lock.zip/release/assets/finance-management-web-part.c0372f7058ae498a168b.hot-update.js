"use strict";
self["webpackHotUpdate_4b0442cb_663c_407a_af12_58b560148ae9_0_0_1"]("finance-management-web-part",{

/***/ 1913:
/*!********************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBar.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavBarStyle.module.scss */ 2784);



var SideNav = function (_a) {
    var onSelect = _a.onSelect;
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null), openMenu = _b[0], setOpenMenu = _b[1];
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(""), activeItem = _c[0], setActiveItem = _c[1];
    var _d = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true), isExpanded = _d[0], setIsExpanded = _d[1];
    var menu = [
        {
            title: "Receivables",
            key: "receivables",
            icon: "pi pi-wallet",
            children: [
                { title: "Report - 1", key: "report1", icon: "pi pi-file" },
                { title: "Report - 2", key: "report2", icon: "pi pi-file" },
            ],
        },
        { title: "Sales Tracker", key: "salesTracker", icon: "pi pi-chart-line" },
        { title: "EEFC Tracker", key: "eefcTracker", icon: "pi pi-dollar" },
        { title: "Invoice", key: "invoice", icon: "pi pi-file-edit" },
        { title: "Payment Request", key: "paymentRequest", icon: "pi pi-credit-card" },
    ];
    var handleClick = function (key) {
        setActiveItem(key);
        if (onSelect)
            onSelect(key);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sidebar, " ").concat(isExpanded ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].expanded : _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].collapsed) },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sidebarContent },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].toggleBtn, onClick: function () { return setIsExpanded(!isExpanded); } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "pi ".concat(isExpanded ? "pi-angle-left" : "pi-angle-right") })),
            menu.map(function (item) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: item.key },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuItem, " ").concat(activeItem === item.key ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].active : ""), onClick: function () {
                        if (item.children) {
                            setOpenMenu(openMenu === item.key ? null : item.key);
                        }
                        else {
                            handleClick(item.key);
                        }
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuLeft },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "".concat(item.icon, " ").concat(activeItem === item.key ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].activeIcon : "") }),
                        isExpanded && react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, item.title)),
                    item.children && isExpanded && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "pi ".concat(openMenu === item.key
                            ? "pi-chevron-down"
                            : "pi-chevron-right") }))),
                item.children && openMenu === item.key && isExpanded && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].subMenu }, item.children.map(function (child) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: child.key, className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].subItem, " ").concat(activeItem === child.key ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].active : ""), onClick: function () { return handleClick(child.key); } },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "".concat(child.icon, " ").concat(activeItem === child.key
                            ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].activeIcon
                            : "") }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, child.title))); }))))); }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SideNav);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("23fbc18a77b376b93834")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=finance-management-web-part.c0372f7058ae498a168b.hot-update.js.map