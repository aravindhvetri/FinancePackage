"use strict";
self["webpackHotUpdate_4b0442cb_663c_407a_af12_58b560148ae9_0_0_1"]("finance-management-web-part",{

/***/ 2784:
/*!**************************************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBarStyle.module.scss.css ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 6323);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".sidebarWrapper_e7df71e0{align-items:center;background:#e6d9c8;display:flex;height:100vh;padding-left:20px}.sidebar_e7df71e0{background:#5b534c;border-radius:25px;display:flex;flex-direction:column;height:90%;padding:20px 10px;position:relative;transition:width .3s ease}.expanded_e7df71e0{width:240px}.collapsed_e7df71e0{width:80px}.toggleBtn_e7df71e0{color:#fff;cursor:pointer;display:flex;justify-content:flex-end;margin-bottom:20px}.menuBlock_e7df71e0{position:relative}.menuItem_e7df71e0{align-items:center;border-radius:10px;color:#ddd;cursor:pointer;display:flex;gap:12px;padding:10px;transition:.2s}.menuItem_e7df71e0:hover{background:hsla(0,0%,100%,.1)}.subMenu_e7df71e0{margin-left:25px}.subItem_e7df71e0{align-items:center;border-radius:8px;cursor:pointer;display:flex;gap:10px;padding:6px}.subItem_e7df71e0:hover{background:hsla(0,0%,100%,.1)}.icon_e7df71e0{font-size:16px}.active_e7df71e0{background:hsla(0,0%,100%,.2);color:#fff}.floatingMenu_e7df71e0{background:#4a433d;border-radius:15px;box-shadow:0 8px 20px rgba(0,0,0,.2);left:90px;padding:10px;position:absolute;top:0;width:160px}.floatingItem_e7df71e0{border-radius:8px;color:#fff;cursor:pointer;padding:8px}.floatingItem_e7df71e0:hover{background:hsla(0,0%,100%,.2)}", true);

// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  sidebarWrapper: "sidebarWrapper_e7df71e0",
  sidebar: "sidebar_e7df71e0",
  expanded: "expanded_e7df71e0",
  collapsed: "collapsed_e7df71e0",
  toggleBtn: "toggleBtn_e7df71e0",
  menuBlock: "menuBlock_e7df71e0",
  menuItem: "menuItem_e7df71e0",
  subMenu: "subMenu_e7df71e0",
  subItem: "subItem_e7df71e0",
  icon: "icon_e7df71e0",
  active: "active_e7df71e0",
  floatingMenu: "floatingMenu_e7df71e0",
  floatingItem: "floatingItem_e7df71e0"
});


/***/ }),

/***/ 1913:
/*!********************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBar.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavBarStyle.module.scss */ 2784);



var SideNav = function (_a) {
    var onSelect = _a.onSelect;
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null), openMenu = _b[0], setOpenMenu = _b[1];
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(""), activeItem = _c[0], setActiveItem = _c[1];
    var _d = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true), isExpanded = _d[0], setIsExpanded = _d[1];
    var menu = [
        {
            title: "Receivables",
            key: "receivables",
            icon: "pi pi-wallet",
            children: [
                { title: "Report - 1", key: "report1", icon: "pi pi-file" },
                { title: "Report - 2", key: "report2", icon: "pi pi-file" },
            ],
        },
        { title: "Sales Tracker", key: "salesTracker", icon: "pi pi-chart-line" },
        { title: "EEFC Tracker", key: "eefcTracker", icon: "pi pi-dollar" },
        { title: "Invoice", key: "invoice", icon: "pi pi-file-edit" },
        { title: "Payment Request", key: "paymentRequest", icon: "pi pi-credit-card" },
    ];
    var handleClick = function (key) {
        setActiveItem(key);
        if (onSelect)
            onSelect(key);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sidebarWrapper },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sidebar, " ").concat(isExpanded ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].expanded : _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].collapsed) },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].toggleBtn },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "pi ".concat(isExpanded ? "pi-angle-left" : "pi-angle-right"), onClick: function () { return setIsExpanded(!isExpanded); } })),
            menu.map(function (item) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: item.key, className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuBlock },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuItem, " ").concat(activeItem === item.key ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].active : ""), onClick: function () {
                        if (item.children) {
                            setOpenMenu(openMenu === item.key ? null : item.key);
                        }
                        else {
                            handleClick(item.key);
                        }
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "".concat(item.icon, " ").concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].icon) }),
                    isExpanded && react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, item.title),
                    item.children && isExpanded && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "pi ".concat(openMenu === item.key
                            ? "pi-chevron-down"
                            : "pi-chevron-right") }))),
                item.children && openMenu === item.key && isExpanded && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].subMenu }, item.children.map(function (child) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: child.key, className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].subItem, " ").concat(activeItem === child.key ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].active : ""), onClick: function () { return handleClick(child.key); } },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "".concat(child.icon, " ").concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].icon) }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, child.title))); }))),
                item.children && openMenu === item.key && !isExpanded && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].floatingMenu }, item.children.map(function (child) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: child.key, className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].floatingItem, onClick: function () { return handleClick(child.key); } }, child.title)); }))))); }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SideNav);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("9f146ae26d181e8c98ce")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=finance-management-web-part.28a222046ae57f0d0de8.hot-update.js.map