"use strict";
self["webpackHotUpdate_4b0442cb_663c_407a_af12_58b560148ae9_0_0_1"]("finance-management-web-part",{

/***/ 2784:
/*!**************************************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBarStyle.module.scss.css ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 6323);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".sidebar_e7df71e0{background:#1e293b;color:#cbd5e1;display:flex;height:100vh;justify-content:center;transition:width .3s ease}.sidebarContent_e7df71e0{align-items:center;display:flex;flex-direction:column;gap:10px;margin-bottom:auto;margin-top:auto;width:100%}.expanded_e7df71e0{width:240px}.collapsed_e7df71e0{width:70px}.toggleBtn_e7df71e0{color:#fff;cursor:pointer;font-size:18px;margin-bottom:20px}.menuItem_e7df71e0{align-items:center;border-radius:8px;cursor:pointer;display:flex;justify-content:space-between;padding:12px;transition:.2s;width:90%}.menuItem_e7df71e0:hover{background:#334155}.menuLeft_e7df71e0{align-items:center;display:flex;gap:12px}.menuLeft_e7df71e0 i{color:#94a3b8;font-size:16px}.subMenu_e7df71e0{margin-left:15px;width:85%}.subItem_e7df71e0{align-items:center;border-radius:6px;cursor:pointer;display:flex;gap:10px;padding:8px}.subItem_e7df71e0:hover{background:#334155}.active_e7df71e0{background:#2563eb;color:#fff}.activeIcon_e7df71e0{color:#fff!important}", true);

// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  sidebar: "sidebar_e7df71e0",
  sidebarContent: "sidebarContent_e7df71e0",
  expanded: "expanded_e7df71e0",
  collapsed: "collapsed_e7df71e0",
  toggleBtn: "toggleBtn_e7df71e0",
  menuItem: "menuItem_e7df71e0",
  menuLeft: "menuLeft_e7df71e0",
  subMenu: "subMenu_e7df71e0",
  subItem: "subItem_e7df71e0",
  active: "active_e7df71e0",
  activeIcon: "activeIcon_e7df71e0"
});


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("9a1dbd16b91785bdbc79")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=finance-management-web-part.23fbc18a77b376b93834.hot-update.js.map