"use strict";
self["webpackHotUpdate_4b0442cb_663c_407a_af12_58b560148ae9_0_0_1"]("finance-management-web-part",{

/***/ 2784:
/*!**************************************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBarStyle.module.scss.css ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 6323);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".sidebar_e7df71e0{background:#f8f9fb;display:flex;flex-direction:column;height:80vh;overflow:hidden;transition:width .3s ease}.open_e7df71e0{width:250px}.closed_e7df71e0{width:80px}.topRight_e7df71e0{display:flex;justify-content:flex-end;padding:15px}.toggleBtn_e7df71e0{align-items:center;background:linear-gradient(135deg,#3f9f4e,#62e476);border-radius:50%;box-shadow:0 4px 10px rgba(0,0,0,.2);color:#fff;cursor:pointer;display:flex;height:35px;justify-content:center;transition:transform .2s ease;width:35px}.toggleBtn_e7df71e0:hover{transform:scale(1.1)}.menuItem_e7df71e0{align-items:center;border-radius:8px;color:#444;cursor:pointer;display:flex;font-weight:600;justify-content:space-between;padding:8px 40px;transition:background-color .2s ease,transform .1s ease}.menuItem_e7df71e0:hover{color:#000}.menuItem_e7df71e0:active{color:#fff;transform:scale(.98)}.menuItem_e7df71e0 i{font-size:14px}.active_e7df71e0{background:#3f9f4e;color:#fff;transition:background-color .2s ease}.subMenu_e7df71e0{margin-left:40px;padding-left:20px;position:relative}.subItem_e7df71e0:hover{color:#000}.subItem_e7df71e0:active{color:#fff}.subMenu_e7df71e0:before{background:#cfd3da;content:\"\";height:100%;left:8px;position:absolute;top:0;width:2px}.subItem_e7df71e0{color:#fff;margin-bottom:6px;padding:8px 10px 8px 20px;position:relative}.subItem_e7df71e0:before{background:#cfd3da;content:\"\";height:2px;left:-12px;position:absolute;top:50%;width:12px}.subItem_e7df71e0:last-child:after{background:#f8f9fb;content:\"\";height:50%;left:-12px;position:absolute;top:50%;width:2px}@keyframes slideDown_e7df71e0{0%{opacity:0;transform:translateY(-5px)}to{opacity:1;transform:translateY(0)}}.subItem_e7df71e0{border-radius:6px;color:#555;cursor:pointer;font-weight:600;margin-bottom:4px;padding:8px 10px;transition:background-color .2s ease}.activeChild_e7df71e0{background:#3f9f4e;color:#fff;transition:background-color .2s ease}.centerNav_e7df71e0{display:flex;flex:1;flex-direction:column;justify-content:center}.bottomUser_e7df71e0{align-items:center;border-top:1px solid #e0e0e0;display:flex;flex-direction:column;gap:10px;padding:15px}.userImage_e7df71e0{border-radius:50%;height:50px;object-fit:cover;width:50px}.userInfo_e7df71e0{display:flex;flex-direction:column}.userName_e7df71e0{font-size:14px;font-weight:600}.userEmail_e7df71e0{color:#777;font-size:12px}", true);

// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  sidebar: "sidebar_e7df71e0",
  open: "open_e7df71e0",
  closed: "closed_e7df71e0",
  topRight: "topRight_e7df71e0",
  toggleBtn: "toggleBtn_e7df71e0",
  centerNav: "centerNav_e7df71e0",
  menuItem: "menuItem_e7df71e0",
  active: "active_e7df71e0",
  subMenu: "subMenu_e7df71e0",
  subItem: "subItem_e7df71e0",
  activeChild: "activeChild_e7df71e0",
  bottomUser: "bottomUser_e7df71e0",
  userImage: "userImage_e7df71e0",
  userInfo: "userInfo_e7df71e0",
  userName: "userName_e7df71e0",
  userEmail: "userEmail_e7df71e0",
  slideDown: "slideDown_e7df71e0"
});


/***/ }),

/***/ 1913:
/*!********************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBar.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavBarStyle.module.scss */ 2784);



var SideNav = function (props) {
    var _a = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("receivables"), openMenu = _a[0], setOpenMenu = _a[1];
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("report1"), activeItem = _b[0], setActiveItem = _b[1];
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true), isOpen = _c[0], setIsOpen = _c[1];
    var menu = [
        {
            title: "Reports",
            key: "receivables",
            icon: "pi pi-wallet",
            children: [
                { title: "Receivables Report - 1", key: "report1" },
                { title: "Receivables Report - 2", key: "report2" },
                {
                    title: "Sales Tracker",
                    key: "salesTracker",
                    icon: "pi pi-chart-line",
                },
                { title: "EEFC Tracker", key: "eefcTracker", icon: "pi pi-dollar" },
            ],
        },
        { title: "Invoice", key: "invoice", icon: "pi pi-file-edit" },
        {
            title: "Payment Request",
            key: "paymentRequest",
            icon: "pi pi-credit-card",
        },
    ];
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        console.log(props, "propspropspropspropsprops");
        console.log(props.context.pageContext.user.email, "props.context.pageContext.user.email");
        console.log(prop);
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sidebar, " ").concat(isOpen ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].open : _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].closed) },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topRight },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].toggleBtn, onClick: function () { return setIsOpen(!isOpen); } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "pi ".concat(isOpen ? "pi-angle-left" : "pi-angle-right") }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { style: { width: "202px", height: "50px", marginLeft: "20px" }, src: __webpack_require__(/*! ../../assets/technorucs-logo BLACK (1) 4.png */ 960), alt: "Logo" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].centerNav }, menu.map(function (item) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: item.key },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuItem, " ").concat(activeItem === item.key ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].active : ""), onClick: function () {
                    if (item.children) {
                        setOpenMenu(openMenu === item.key ? null : item.key);
                    }
                    else {
                        setActiveItem(item.key);
                    }
                } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: item.icon }),
                isOpen && react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, item.title),
                item.children && isOpen && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "pi ".concat(openMenu === item.key
                        ? "pi-chevron-down"
                        : "pi-chevron-right") }))),
            item.children && openMenu === item.key && isOpen && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].subMenu }, item.children.map(function (child) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: child.key, className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].subItem, " ").concat(activeItem === child.key ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].activeChild : ""), onClick: function () { return setActiveItem(child.key); } }, child.title)); }))))); })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].bottomUser },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].userImage, src: "/_layouts/15/userphoto.aspx?size=S&username=".concat(props.context.pageContext.user.email), alt: "User" }),
            isOpen && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].userInfo },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].userName }, props.context.pageContext.user.displayName))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SideNav);


/***/ }),

/***/ 960:
/*!*******************************************************************************!*\
  !*** ./lib/webparts/financeManagement/assets/technorucs-logo BLACK (1) 4.png ***!
  \*******************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "technorucs-logo BLACK (1) 4_8cc1fc0830900cedc003.png";

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("87439a3dcd1404ccd24b")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=finance-management-web-part.731103c21185bc1d5725.hot-update.js.map