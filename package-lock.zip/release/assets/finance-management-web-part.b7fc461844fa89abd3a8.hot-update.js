self["webpackHotUpdate_4b0442cb_663c_407a_af12_58b560148ae9_0_0_1"]("finance-management-web-part",{

/***/ 1913:
/*!********************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBar.js ***!
  \********************************************************************/
/***/ (() => {

throw new Error("Module parse failed: The keyword 'private' is reserved (34:20)\nFile was processed with these loaders:\n * ./node_modules/source-map-loader/dist/cjs.js\nYou may need an additional loader to handle the result of these loaders.\n|         console.log(props, \"propspropspropspropsprops\");\n|         console.log(props.context.pageContext.user.email, \"props.context.pageContext.user.email\");\n>         console.log(private, _value, string);\n|     }, public, get, value(), string, {\n|         return: _this._value");

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("731103c21185bc1d5725")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=finance-management-web-part.b7fc461844fa89abd3a8.hot-update.js.map