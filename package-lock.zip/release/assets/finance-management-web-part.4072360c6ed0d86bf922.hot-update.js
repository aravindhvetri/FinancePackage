"use strict";
self["webpackHotUpdate_4b0442cb_663c_407a_af12_58b560148ae9_0_0_1"]("finance-management-web-part",{

/***/ 2784:
/*!**************************************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBarStyle.module.scss.css ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 6323);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".sidebar_e7df71e0{background:#f8f9fb;display:flex;flex-direction:column;height:100vh;overflow:hidden;position:relative;transition:width .3s ease}.open_e7df71e0{width:250px}.closed_e7df71e0{width:80px}.topRight_e7df71e0{display:flex;justify-content:flex-end;padding:15px}.centerNav_e7df71e0{flex:1}.toggleBtn_e7df71e0{align-items:center;background:linear-gradient(135deg,#3f9f4e,#62e476);border-radius:50%;box-shadow:0 4px 10px rgba(0,0,0,.2);color:#fff;cursor:pointer;display:flex;height:35px;justify-content:center;transition:.3s ease;width:35px}.toggleBtn_e7df71e0:hover{transform:scale(1.1)}.centerNav_e7df71e0{display:flex;flex-direction:column;justify-content:center;width:100%}.menuItem_e7df71e0{align-items:center;border-radius:8px;color:#444;cursor:pointer;display:flex;justify-content:space-between;padding:12px 60px;transition:.2s ease}.menuItem_e7df71e0:hover{background:#e9edf5}.menuItem_e7df71e0 i{font-size:14px}.active_e7df71e0{background:#3f9f4e;color:#fff}.active_e7df71e0 i{color:#fff}.subMenu_e7df71e0{border-left:2px solid #dcdfe6;margin-left:35px;margin-top:5px;padding-left:15px}.subItem_e7df71e0{border-radius:6px;color:#555;cursor:pointer;margin-bottom:4px;padding:8px 10px;position:relative}.subItem_e7df71e0:before{background:#dcdfe6;content:\"\";height:2px;left:-17px;position:absolute;top:14px;width:12px}.subItem_e7df71e0:hover{background:#e9edf5}.activeChild_e7df71e0{background:#3f9f4e;color:#fff;font-weight:500}.activeChild_e7df71e0:before{background:#fff}", true);

// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  sidebar: "sidebar_e7df71e0",
  open: "open_e7df71e0",
  closed: "closed_e7df71e0",
  topRight: "topRight_e7df71e0",
  centerNav: "centerNav_e7df71e0",
  toggleBtn: "toggleBtn_e7df71e0",
  menuItem: "menuItem_e7df71e0",
  active: "active_e7df71e0",
  subMenu: "subMenu_e7df71e0",
  subItem: "subItem_e7df71e0",
  activeChild: "activeChild_e7df71e0"
});


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("98e88e0fbc8902e0030d")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=finance-management-web-part.4072360c6ed0d86bf922.hot-update.js.map