"use strict";
self["webpackHotUpdate_4b0442cb_663c_407a_af12_58b560148ae9_0_0_1"]("finance-management-web-part",{

/***/ 2784:
/*!**************************************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBarStyle.module.scss.css ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 6323);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".sidebar_e7df71e0{background:#f8f9fb;display:flex;flex-direction:column;height:100vh;overflow:hidden;transition:width .3s ease}.open_e7df71e0{width:250px}.closed_e7df71e0{width:80px}.topRight_e7df71e0{display:flex;justify-content:flex-end;padding:15px}.toggleBtn_e7df71e0{align-items:center;background:linear-gradient(135deg,#3f9f4e,#62e476);border-radius:50%;box-shadow:0 4px 10px rgba(0,0,0,.2);color:#fff;cursor:pointer;display:flex;height:35px;justify-content:center;transition:transform .2s ease;width:35px}.toggleBtn_e7df71e0:hover{transform:scale(1.1)}.menuItem_e7df71e0{align-items:center;border-radius:8px;color:#444;cursor:pointer;display:flex;font-weight:600;justify-content:space-between;padding:12px 40px;transition:background-color .2s ease,transform .1s ease}.menuItem_e7df71e0:active{transform:scale(.98)}.menuItem_e7df71e0 i{font-size:14px}.active_e7df71e0{background:#3f9f4e;color:#fff;transition:background-color .2s ease}.subMenu_e7df71e0{margin-left:40px;padding-left:20px;position:relative}.subMenu_e7df71e0:before{background:#cfd3da;content:\"\";height:100%;left:8px;position:absolute;top:0;width:2px}.subItem_e7df71e0{color:#fff;margin-bottom:6px;padding:8px 10px 8px 20px;position:relative}.subItem_e7df71e0:before{background:#cfd3da;content:\"\";height:2px;left:-12px;position:absolute;top:50%;width:12px}.subItem_e7df71e0:last-child:after{background:#f8f9fb;content:\"\";height:50%;left:-12px;position:absolute;top:50%;width:2px}@keyframes slideDown_e7df71e0{0%{opacity:0;transform:translateY(-5px)}to{opacity:1;transform:translateY(0)}}.subItem_e7df71e0{border-radius:6px;color:#555;cursor:pointer;font-weight:600;margin-bottom:4px;padding:8px 10px;transition:background-color .2s ease}.activeChild_e7df71e0{background:#3f9f4e;color:#fff;transition:background-color .2s ease}.centerNav_e7df71e0{display:flex;flex:1;flex-direction:column;justify-content:center}.bottomUser_e7df71e0{align-items:center;border-top:1px solid #e0e0e0;display:flex;flex-direction:column;gap:10px;padding:15px}.userImage_e7df71e0{border-radius:50%;height:35px;object-fit:cover;width:35px}.userInfo_e7df71e0{display:flex;flex-direction:column}.userName_e7df71e0{font-size:14px;font-weight:600}.userEmail_e7df71e0{color:#777;font-size:12px}", true);

// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  sidebar: "sidebar_e7df71e0",
  open: "open_e7df71e0",
  closed: "closed_e7df71e0",
  topRight: "topRight_e7df71e0",
  toggleBtn: "toggleBtn_e7df71e0",
  centerNav: "centerNav_e7df71e0",
  menuItem: "menuItem_e7df71e0",
  active: "active_e7df71e0",
  subMenu: "subMenu_e7df71e0",
  subItem: "subItem_e7df71e0",
  activeChild: "activeChild_e7df71e0",
  bottomUser: "bottomUser_e7df71e0",
  userImage: "userImage_e7df71e0",
  userInfo: "userInfo_e7df71e0",
  userName: "userName_e7df71e0",
  userEmail: "userEmail_e7df71e0",
  slideDown: "slideDown_e7df71e0"
});


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("1cf7854df07774808582")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=finance-management-web-part.9f6e6f23dda161b30192.hot-update.js.map