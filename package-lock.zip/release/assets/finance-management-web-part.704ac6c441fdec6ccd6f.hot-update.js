"use strict";
self["webpackHotUpdate_4b0442cb_663c_407a_af12_58b560148ae9_0_0_1"]("finance-management-web-part",{

/***/ 2784:
/*!**************************************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBarStyle.module.scss.css ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 6323);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".sidebar_e7df71e0{background:#1e293b;color:#cbd5e1;display:flex;flex-direction:column;height:100vh;transition:width .3s ease}.expanded_e7df71e0{width:240px}.collapsed_e7df71e0{width:70px}.topBar_e7df71e0{align-items:center;display:flex;justify-content:space-between;padding:15px}.toggleIcon_e7df71e0{color:#fff;cursor:pointer;font-size:18px}.navContainer_e7df71e0{flex:1}.menuItem_e7df71e0{align-items:center;cursor:pointer;display:flex;justify-content:space-between;padding:12px 15px;transition:.2s}.menuItem_e7df71e0:hover{background:#334155}.menuLeft_e7df71e0{align-items:center;display:flex;gap:12px}.menuLeft_e7df71e0 i{color:#94a3b8;font-size:16px}.subMenu_e7df71e0{margin-left:30px}.subItem_e7df71e0{align-items:center;cursor:pointer;display:flex;gap:10px;padding:8px 10px}.subItem_e7df71e0:hover{background:#334155}.active_e7df71e0{background:#2563eb;color:#fff}.activeIcon_e7df71e0{color:#fff!important}", true);

// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  sidebar: "sidebar_e7df71e0",
  expanded: "expanded_e7df71e0",
  collapsed: "collapsed_e7df71e0",
  topBar: "topBar_e7df71e0",
  toggleIcon: "toggleIcon_e7df71e0",
  navContainer: "navContainer_e7df71e0",
  menuItem: "menuItem_e7df71e0",
  menuLeft: "menuLeft_e7df71e0",
  subMenu: "subMenu_e7df71e0",
  subItem: "subItem_e7df71e0",
  active: "active_e7df71e0",
  activeIcon: "activeIcon_e7df71e0"
});


/***/ }),

/***/ 2355:
/*!************************************************!*\
  !*** ./node_modules/primeicons/primeicons.css ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 6323);
/* harmony import */ var _css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../css-loader/dist/runtime/getUrl.js */ 5780);
/* harmony import */ var _css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _fonts_primeicons_eot__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./fonts/primeicons.eot */ 5844);
/* harmony import */ var _fonts_primeicons_woff2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./fonts/primeicons.woff2 */ 4696);
/* harmony import */ var _fonts_primeicons_woff__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./fonts/primeicons.woff */ 478);
/* harmony import */ var _fonts_primeicons_ttf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./fonts/primeicons.ttf */ 9806);
/* harmony import */ var _fonts_primeicons_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./fonts/primeicons.svg */ 8858);
// Imports








var ___CSS_LOADER_URL_REPLACEMENT_0___ = _css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_fonts_primeicons_eot__WEBPACK_IMPORTED_MODULE_2__)
var ___CSS_LOADER_URL_REPLACEMENT_2___ = _css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_fonts_primeicons_woff2__WEBPACK_IMPORTED_MODULE_3__)
var ___CSS_LOADER_URL_REPLACEMENT_3___ = _css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_fonts_primeicons_woff__WEBPACK_IMPORTED_MODULE_4__)
var ___CSS_LOADER_URL_REPLACEMENT_4___ = _css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_fonts_primeicons_ttf__WEBPACK_IMPORTED_MODULE_5__)
var ___CSS_LOADER_URL_REPLACEMENT_5___ = _css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_fonts_primeicons_svg__WEBPACK_IMPORTED_MODULE_6__)
_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles("@font-face{font-display:block;font-family:primeicons;font-style:normal;font-weight:400;src:url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");src:url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") format('embedded-opentype'), url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") format('woff2'), url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") format('woff'), url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") format('truetype'), url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") format('svg')}.pi{speak:none;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;display:inline-block;font-family:primeicons;font-style:normal;font-variant:normal;font-weight:400;line-height:1;text-transform:none}.pi:before{--webkit-backface-visibility:hidden;backface-visibility:hidden}.pi-fw{text-align:center;width:1.28571429em}.pi-spin{animation:fa-spin 2s linear infinite}@keyframes fa-spin{0%{transform:rotate(0deg)}to{transform:rotate(359deg)}}.pi-eraser:before{content:\"\\ea04\"}.pi-stopwatch:before{content:\"\\ea01\"}.pi-verified:before{content:\"\\ea02\"}.pi-delete-left:before{content:\"\\ea03\"}.pi-hourglass:before{content:\"\\e9fe\"}.pi-truck:before{content:\"\\ea00\"}.pi-wrench:before{content:\"\\e9ff\"}.pi-microphone:before{content:\"\\e9fa\"}.pi-megaphone:before{content:\"\\e9fb\"}.pi-arrow-right-arrow-left:before{content:\"\\e9fc\"}.pi-bitcoin:before{content:\"\\e9fd\"}.pi-file-edit:before{content:\"\\e9f6\"}.pi-language:before{content:\"\\e9f7\"}.pi-file-export:before{content:\"\\e9f8\"}.pi-file-import:before{content:\"\\e9f9\"}.pi-file-word:before{content:\"\\e9f1\"}.pi-gift:before{content:\"\\e9f2\"}.pi-cart-plus:before{content:\"\\e9f3\"}.pi-thumbs-down-fill:before{content:\"\\e9f4\"}.pi-thumbs-up-fill:before{content:\"\\e9f5\"}.pi-arrows-alt:before{content:\"\\e9f0\"}.pi-calculator:before{content:\"\\e9ef\"}.pi-sort-alt-slash:before{content:\"\\e9ee\"}.pi-arrows-h:before{content:\"\\e9ec\"}.pi-arrows-v:before{content:\"\\e9ed\"}.pi-pound:before{content:\"\\e9eb\"}.pi-prime:before{content:\"\\e9ea\"}.pi-chart-pie:before{content:\"\\e9e9\"}.pi-reddit:before{content:\"\\e9e8\"}.pi-code:before{content:\"\\e9e7\"}.pi-sync:before{content:\"\\e9e6\"}.pi-shopping-bag:before{content:\"\\e9e5\"}.pi-server:before{content:\"\\e9e4\"}.pi-database:before{content:\"\\e9e3\"}.pi-hashtag:before{content:\"\\e9e2\"}.pi-bookmark-fill:before{content:\"\\e9df\"}.pi-filter-fill:before{content:\"\\e9e0\"}.pi-heart-fill:before{content:\"\\e9e1\"}.pi-flag-fill:before{content:\"\\e9de\"}.pi-circle:before{content:\"\\e9dc\"}.pi-circle-fill:before{content:\"\\e9dd\"}.pi-bolt:before{content:\"\\e9db\"}.pi-history:before{content:\"\\e9da\"}.pi-box:before{content:\"\\e9d9\"}.pi-at:before{content:\"\\e9d8\"}.pi-arrow-up-right:before{content:\"\\e9d4\"}.pi-arrow-up-left:before{content:\"\\e9d5\"}.pi-arrow-down-left:before{content:\"\\e9d6\"}.pi-arrow-down-right:before{content:\"\\e9d7\"}.pi-telegram:before{content:\"\\e9d3\"}.pi-stop-circle:before{content:\"\\e9d2\"}.pi-stop:before{content:\"\\e9d1\"}.pi-whatsapp:before{content:\"\\e9d0\"}.pi-building:before{content:\"\\e9cf\"}.pi-qrcode:before{content:\"\\e9ce\"}.pi-car:before{content:\"\\e9cd\"}.pi-instagram:before{content:\"\\e9cc\"}.pi-linkedin:before{content:\"\\e9cb\"}.pi-send:before{content:\"\\e9ca\"}.pi-slack:before{content:\"\\e9c9\"}.pi-sun:before{content:\"\\e9c8\"}.pi-moon:before{content:\"\\e9c7\"}.pi-vimeo:before{content:\"\\e9c6\"}.pi-youtube:before{content:\"\\e9c5\"}.pi-flag:before{content:\"\\e9c4\"}.pi-wallet:before{content:\"\\e9c3\"}.pi-map:before{content:\"\\e9c2\"}.pi-link:before{content:\"\\e9c1\"}.pi-credit-card:before{content:\"\\e9bf\"}.pi-discord:before{content:\"\\e9c0\"}.pi-percentage:before{content:\"\\e9be\"}.pi-euro:before{content:\"\\e9bd\"}.pi-book:before{content:\"\\e9ba\"}.pi-shield:before{content:\"\\e9b9\"}.pi-paypal:before{content:\"\\e9bb\"}.pi-amazon:before{content:\"\\e9bc\"}.pi-phone:before{content:\"\\e9b8\"}.pi-filter-slash:before{content:\"\\e9b7\"}.pi-facebook:before{content:\"\\e9b4\"}.pi-github:before{content:\"\\e9b5\"}.pi-twitter:before{content:\"\\e9b6\"}.pi-step-backward-alt:before{content:\"\\e9ac\"}.pi-step-forward-alt:before{content:\"\\e9ad\"}.pi-forward:before{content:\"\\e9ae\"}.pi-backward:before{content:\"\\e9af\"}.pi-fast-backward:before{content:\"\\e9b0\"}.pi-fast-forward:before{content:\"\\e9b1\"}.pi-pause:before{content:\"\\e9b2\"}.pi-play:before{content:\"\\e9b3\"}.pi-compass:before{content:\"\\e9ab\"}.pi-id-card:before{content:\"\\e9aa\"}.pi-ticket:before{content:\"\\e9a9\"}.pi-file-o:before{content:\"\\e9a8\"}.pi-reply:before{content:\"\\e9a7\"}.pi-directions-alt:before{content:\"\\e9a5\"}.pi-directions:before{content:\"\\e9a6\"}.pi-thumbs-up:before{content:\"\\e9a3\"}.pi-thumbs-down:before{content:\"\\e9a4\"}.pi-sort-numeric-down-alt:before{content:\"\\e996\"}.pi-sort-numeric-up-alt:before{content:\"\\e997\"}.pi-sort-alpha-down-alt:before{content:\"\\e998\"}.pi-sort-alpha-up-alt:before{content:\"\\e999\"}.pi-sort-numeric-down:before{content:\"\\e99a\"}.pi-sort-numeric-up:before{content:\"\\e99b\"}.pi-sort-alpha-down:before{content:\"\\e99c\"}.pi-sort-alpha-up:before{content:\"\\e99d\"}.pi-sort-alt:before{content:\"\\e99e\"}.pi-sort-amount-up:before{content:\"\\e99f\"}.pi-sort-amount-down:before{content:\"\\e9a0\"}.pi-sort-amount-down-alt:before{content:\"\\e9a1\"}.pi-sort-amount-up-alt:before{content:\"\\e9a2\"}.pi-palette:before{content:\"\\e995\"}.pi-undo:before{content:\"\\e994\"}.pi-desktop:before{content:\"\\e993\"}.pi-sliders-v:before{content:\"\\e991\"}.pi-sliders-h:before{content:\"\\e992\"}.pi-search-plus:before{content:\"\\e98f\"}.pi-search-minus:before{content:\"\\e990\"}.pi-file-excel:before{content:\"\\e98e\"}.pi-file-pdf:before{content:\"\\e98d\"}.pi-check-square:before{content:\"\\e98c\"}.pi-chart-line:before{content:\"\\e98b\"}.pi-user-edit:before{content:\"\\e98a\"}.pi-exclamation-circle:before{content:\"\\e989\"}.pi-android:before{content:\"\\e985\"}.pi-google:before{content:\"\\e986\"}.pi-apple:before{content:\"\\e987\"}.pi-microsoft:before{content:\"\\e988\"}.pi-heart:before{content:\"\\e984\"}.pi-mobile:before{content:\"\\e982\"}.pi-tablet:before{content:\"\\e983\"}.pi-key:before{content:\"\\e981\"}.pi-shopping-cart:before{content:\"\\e980\"}.pi-comments:before{content:\"\\e97e\"}.pi-comment:before{content:\"\\e97f\"}.pi-briefcase:before{content:\"\\e97d\"}.pi-bell:before{content:\"\\e97c\"}.pi-paperclip:before{content:\"\\e97b\"}.pi-share-alt:before{content:\"\\e97a\"}.pi-envelope:before{content:\"\\e979\"}.pi-volume-down:before{content:\"\\e976\"}.pi-volume-up:before{content:\"\\e977\"}.pi-volume-off:before{content:\"\\e978\"}.pi-eject:before{content:\"\\e975\"}.pi-money-bill:before{content:\"\\e974\"}.pi-images:before{content:\"\\e973\"}.pi-image:before{content:\"\\e972\"}.pi-sign-in:before{content:\"\\e970\"}.pi-sign-out:before{content:\"\\e971\"}.pi-wifi:before{content:\"\\e96f\"}.pi-sitemap:before{content:\"\\e96e\"}.pi-chart-bar:before{content:\"\\e96d\"}.pi-camera:before{content:\"\\e96c\"}.pi-dollar:before{content:\"\\e96b\"}.pi-lock-open:before{content:\"\\e96a\"}.pi-table:before{content:\"\\e969\"}.pi-map-marker:before{content:\"\\e968\"}.pi-list:before{content:\"\\e967\"}.pi-eye-slash:before{content:\"\\e965\"}.pi-eye:before{content:\"\\e966\"}.pi-folder-open:before{content:\"\\e964\"}.pi-folder:before{content:\"\\e963\"}.pi-video:before{content:\"\\e962\"}.pi-inbox:before{content:\"\\e961\"}.pi-lock:before{content:\"\\e95f\"}.pi-unlock:before{content:\"\\e960\"}.pi-tags:before{content:\"\\e95d\"}.pi-tag:before{content:\"\\e95e\"}.pi-power-off:before{content:\"\\e95c\"}.pi-save:before{content:\"\\e95b\"}.pi-question-circle:before{content:\"\\e959\"}.pi-question:before{content:\"\\e95a\"}.pi-copy:before{content:\"\\e957\"}.pi-file:before{content:\"\\e958\"}.pi-clone:before{content:\"\\e955\"}.pi-calendar-times:before{content:\"\\e952\"}.pi-calendar-minus:before{content:\"\\e953\"}.pi-calendar-plus:before{content:\"\\e954\"}.pi-ellipsis-v:before{content:\"\\e950\"}.pi-ellipsis-h:before{content:\"\\e951\"}.pi-bookmark:before{content:\"\\e94e\"}.pi-globe:before{content:\"\\e94f\"}.pi-replay:before{content:\"\\e94d\"}.pi-filter:before{content:\"\\e94c\"}.pi-print:before{content:\"\\e94b\"}.pi-align-right:before{content:\"\\e946\"}.pi-align-left:before{content:\"\\e947\"}.pi-align-center:before{content:\"\\e948\"}.pi-align-justify:before{content:\"\\e949\"}.pi-cog:before{content:\"\\e94a\"}.pi-cloud-download:before{content:\"\\e943\"}.pi-cloud-upload:before{content:\"\\e944\"}.pi-cloud:before{content:\"\\e945\"}.pi-pencil:before{content:\"\\e942\"}.pi-users:before{content:\"\\e941\"}.pi-clock:before{content:\"\\e940\"}.pi-user-minus:before{content:\"\\e93e\"}.pi-user-plus:before{content:\"\\e93f\"}.pi-trash:before{content:\"\\e93d\"}.pi-external-link:before{content:\"\\e93c\"}.pi-window-maximize:before{content:\"\\e93b\"}.pi-window-minimize:before{content:\"\\e93a\"}.pi-refresh:before{content:\"\\e938\"}.pi-user:before{content:\"\\e939\"}.pi-exclamation-triangle:before{content:\"\\e922\"}.pi-calendar:before{content:\"\\e927\"}.pi-chevron-circle-left:before{content:\"\\e928\"}.pi-chevron-circle-down:before{content:\"\\e929\"}.pi-chevron-circle-right:before{content:\"\\e92a\"}.pi-chevron-circle-up:before{content:\"\\e92b\"}.pi-angle-double-down:before{content:\"\\e92c\"}.pi-angle-double-left:before{content:\"\\e92d\"}.pi-angle-double-right:before{content:\"\\e92e\"}.pi-angle-double-up:before{content:\"\\e92f\"}.pi-angle-down:before{content:\"\\e930\"}.pi-angle-left:before{content:\"\\e931\"}.pi-angle-right:before{content:\"\\e932\"}.pi-angle-up:before{content:\"\\e933\"}.pi-upload:before{content:\"\\e934\"}.pi-download:before{content:\"\\e956\"}.pi-ban:before{content:\"\\e935\"}.pi-star-fill:before{content:\"\\e936\"}.pi-star:before{content:\"\\e937\"}.pi-chevron-left:before{content:\"\\e900\"}.pi-chevron-right:before{content:\"\\e901\"}.pi-chevron-down:before{content:\"\\e902\"}.pi-chevron-up:before{content:\"\\e903\"}.pi-caret-left:before{content:\"\\e904\"}.pi-caret-right:before{content:\"\\e905\"}.pi-caret-down:before{content:\"\\e906\"}.pi-caret-up:before{content:\"\\e907\"}.pi-search:before{content:\"\\e908\"}.pi-check:before{content:\"\\e909\"}.pi-check-circle:before{content:\"\\e90a\"}.pi-times:before{content:\"\\e90b\"}.pi-times-circle:before{content:\"\\e90c\"}.pi-plus:before{content:\"\\e90d\"}.pi-plus-circle:before{content:\"\\e90e\"}.pi-minus:before{content:\"\\e90f\"}.pi-minus-circle:before{content:\"\\e910\"}.pi-circle-on:before{content:\"\\e911\"}.pi-circle-off:before{content:\"\\e912\"}.pi-sort-down:before{content:\"\\e913\"}.pi-sort-up:before{content:\"\\e914\"}.pi-sort:before{content:\"\\e915\"}.pi-step-backward:before{content:\"\\e916\"}.pi-step-forward:before{content:\"\\e917\"}.pi-th-large:before{content:\"\\e918\"}.pi-arrow-down:before{content:\"\\e919\"}.pi-arrow-left:before{content:\"\\e91a\"}.pi-arrow-right:before{content:\"\\e91b\"}.pi-arrow-up:before{content:\"\\e91c\"}.pi-bars:before{content:\"\\e91d\"}.pi-arrow-circle-down:before{content:\"\\e91e\"}.pi-arrow-circle-left:before{content:\"\\e91f\"}.pi-arrow-circle-right:before{content:\"\\e920\"}.pi-arrow-circle-up:before{content:\"\\e921\"}.pi-info:before{content:\"\\e923\"}.pi-info-circle:before{content:\"\\e924\"}.pi-home:before{content:\"\\e925\"}.pi-spinner:before{content:\"\\e926\"}", true);


/***/ }),

/***/ 1913:
/*!********************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBar.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavBarStyle.module.scss */ 2784);
/* harmony import */ var primeicons_primeicons_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! primeicons/primeicons.css */ 2355);




var SideNav = function (_a) {
    var onSelect = _a.onSelect;
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null), openMenu = _b[0], setOpenMenu = _b[1];
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(""), activeItem = _c[0], setActiveItem = _c[1];
    var _d = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true), isExpanded = _d[0], setIsExpanded = _d[1];
    var menu = [
        {
            title: "Receivables",
            key: "receivables",
            icon: "pi pi-wallet",
            children: [
                { title: "Report - 1", key: "report1", icon: "pi pi-file" },
                { title: "Report - 2", key: "report2", icon: "pi pi-file" },
            ],
        },
        { title: "Sales Tracker", key: "salesTracker", icon: "pi pi-chart-line" },
        { title: "EEFC Tracker", key: "eefcTracker", icon: "pi pi-dollar" },
        { title: "Invoice", key: "invoice", icon: "pi pi-file-edit" },
        { title: "Payment Request", key: "paymentRequest", icon: "pi pi-credit-card" },
    ];
    var handleClick = function (key) {
        setActiveItem(key);
        if (onSelect)
            onSelect(key);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sidebar, " ").concat(isExpanded ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].expanded : _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].collapsed) },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBar },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null),
            " ",
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "pi ".concat(isExpanded ? "pi-angle-left" : "pi-angle-right", " ").concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].toggleIcon), onClick: function () { return setIsExpanded(!isExpanded); } })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].navContainer }, menu.map(function (item) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: item.key },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuItem, " ").concat(activeItem === item.key ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].active : ""), onClick: function () {
                    if (item.children) {
                        setOpenMenu(openMenu === item.key ? null : item.key);
                    }
                    else {
                        handleClick(item.key);
                    }
                } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuLeft },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "".concat(item.icon, " ").concat(activeItem === item.key ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].activeIcon : "") }),
                    isExpanded && react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, item.title)),
                item.children && isExpanded && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "pi ".concat(openMenu === item.key
                        ? "pi-chevron-down"
                        : "pi-chevron-right") }))),
            item.children && openMenu === item.key && isExpanded && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].subMenu }, item.children.map(function (child) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: child.key, className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].subItem, " ").concat(activeItem === child.key ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].active : ""), onClick: function () { return handleClick(child.key); } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "".concat(child.icon, " ").concat(activeItem === child.key
                        ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].activeIcon
                        : "") }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, child.title))); }))))); }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SideNav);


/***/ }),

/***/ 5780:
/*!********************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/getUrl.js ***!
  \********************************************************/
/***/ ((module) => {



module.exports = function (url, options) {
  if (!options) {
    options = {};
  }
  if (!url) {
    return url;
  }
  url = String(url.__esModule ? url.default : url);

  // If url is already wrapped in quotes, remove them
  if (/^['"].*['"]$/.test(url)) {
    url = url.slice(1, -1);
  }
  if (options.hash) {
    url += options.hash;
  }

  // Should url be wrapped?
  // See https://drafts.csswg.org/css-values-3/#urls
  if (/["'() \t\n]|(%20)/.test(url) || options.needQuotes) {
    return "\"".concat(url.replace(/"/g, '\\"').replace(/\n/g, "\\n"), "\"");
  }
  return url;
};

/***/ }),

/***/ 5844:
/*!******************************************************!*\
  !*** ./node_modules/primeicons/fonts/primeicons.eot ***!
  \******************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "primeicons_c08d00cac4f2edb5ade3.eot";

/***/ }),

/***/ 8858:
/*!******************************************************!*\
  !*** ./node_modules/primeicons/fonts/primeicons.svg ***!
  \******************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "primeicons_1d854e3ab2c37173804a.svg";

/***/ }),

/***/ 9806:
/*!******************************************************!*\
  !*** ./node_modules/primeicons/fonts/primeicons.ttf ***!
  \******************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "primeicons_acb19296cb26b15dcf42.ttf";

/***/ }),

/***/ 478:
/*!*******************************************************!*\
  !*** ./node_modules/primeicons/fonts/primeicons.woff ***!
  \*******************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "primeicons_062070972fbad0f4fbb3.woff";

/***/ }),

/***/ 4696:
/*!********************************************************!*\
  !*** ./node_modules/primeicons/fonts/primeicons.woff2 ***!
  \********************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "primeicons_c0929a1e055f2ceb5c88.woff2";

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("58688702bc968eae08c5")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=finance-management-web-part.704ac6c441fdec6ccd6f.hot-update.js.map