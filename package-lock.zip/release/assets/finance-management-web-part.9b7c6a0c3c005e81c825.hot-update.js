"use strict";
self["webpackHotUpdate_4b0442cb_663c_407a_af12_58b560148ae9_0_0_1"]("finance-management-web-part",{

/***/ 1913:
/*!********************************************************************!*\
  !*** ./lib/webparts/financeManagement/components/NavBar/NavBar.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavBarStyle.module.scss */ 2784);



var SideNav = function (props) {
    var _a, _b;
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("receivables"), openMenu = _c[0], setOpenMenu = _c[1];
    var _d = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("report1"), activeItem = _d[0], setActiveItem = _d[1];
    var _e = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true), isOpen = _e[0], setIsOpen = _e[1];
    var menu = [
        {
            title: "Receivables",
            key: "receivables",
            icon: "pi pi-wallet",
            children: [
                { title: "Report - 1", key: "report1" },
                { title: "Report - 2", key: "report2" },
            ],
        },
        { title: "Sales Tracker", key: "salesTracker", icon: "pi pi-chart-line" },
        { title: "EEFC Tracker", key: "eefcTracker", icon: "pi pi-dollar" },
        { title: "Invoice", key: "invoice", icon: "pi pi-file-edit" },
        { title: "Payment Request", key: "paymentRequest", icon: "pi pi-credit-card" },
    ];
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        console.log(props, "propspropspropspropsprops");
        log;
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sidebar, " ").concat(isOpen ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].open : _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].closed) },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topRight },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].toggleBtn, onClick: function () { return setIsOpen(!isOpen); } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "pi ".concat(isOpen ? "pi-angle-left" : "pi-angle-right") }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { style: { width: "202px",
                    height: "50px",
                    marginLeft: "20px" }, src: __webpack_require__(/*! ../../assets/technorucs-logo BLACK (1) 4.png */ 960), alt: "Logo" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].centerNav }, menu.map(function (item) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: item.key },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuItem, " ").concat(activeItem === item.key ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].active : ""), onClick: function () {
                    if (item.children) {
                        setOpenMenu(openMenu === item.key ? null : item.key);
                    }
                    else {
                        setActiveItem(item.key);
                    }
                } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: item.icon }),
                isOpen && react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, item.title),
                item.children && isOpen && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "pi ".concat(openMenu === item.key
                        ? "pi-chevron-down"
                        : "pi-chevron-right") }))),
            item.children && openMenu === item.key && isOpen && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].subMenu }, item.children.map(function (child) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: child.key, className: "".concat(_NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].subItem, " ").concat(activeItem === child.key
                    ? _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].activeChild
                    : ""), onClick: function () {
                    return setActiveItem(child.key);
                } }, child.title)); }))))); })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].bottomUser },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].userImage, src: "/_layouts/15/userphoto.aspx?size=S&username=".concat((_a = props.context.pageContext.user.email) === null || _a === void 0 ? void 0 : _a.email), alt: "User" }),
            isOpen && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].userInfo },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].userName }, (_b = props.context.pageContext.user.email) === null || _b === void 0 ? void 0 : _b.displayName),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _NavBarStyle_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].userEmail }, props.context.pageContext.user.email))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SideNav);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("56314ce28b3ccdceaa1b")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=finance-management-web-part.9b7c6a0c3c005e81c825.hot-update.js.map