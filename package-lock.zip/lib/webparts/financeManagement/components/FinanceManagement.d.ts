import * as React from 'react';
import type { IFinanceManagementProps } from './IFinanceManagementProps';
export default class FinanceManagement extends React.Component<IFinanceManagementProps> {
    constructor(prop: IFinanceManagementProps, state: {});
    render(): React.ReactElement<IFinanceManagementProps>;
}
//# sourceMappingURL=FinanceManagement.d.ts.map