declare const SideNav: (props: any) => JSX.Element;
export default SideNav;
//# sourceMappingURL=NavBar.d.ts.map