import { Version } from '@microsoft/sp-core-library';
import { type IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
import "primereact/resources/themes/bootstrap4-light-blue/theme.css";
export interface IFinanceManagementWebPartProps {
    description: string;
}
export default class FinanceManagementWebPart extends BaseClientSideWebPart<IFinanceManagementWebPartProps> {
    private _isDarkTheme;
    private _environmentMessage;
    render(): void;
    constructor();
    protected onInit(): Promise<void>;
    private _getEnvironmentMessage;
    protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=FinanceManagementWebPart.d.ts.map