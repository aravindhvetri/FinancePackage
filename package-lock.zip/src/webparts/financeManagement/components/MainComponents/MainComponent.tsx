import * as React from "react";
import "../../../../ExternalRef/CSS/Style.css";
import NavBar from "../NavBar/NavBar";

const MainComponent = (props: any) => {
  return <div>
    <><NavBar context={props.context}/></></div>;
};
export default MainComponent;
