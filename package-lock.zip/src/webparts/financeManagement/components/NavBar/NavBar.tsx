import * as React from "react";
import { useState } from "react";
import styles from "./NavBarStyle.module.scss";
import { PrimeIcons } from "primereact/api";

const SideNav = (props: any) => {
  const [openMenu, setOpenMenu] = useState<string | null>("receivables");
  const [activeItem, setActiveItem] = useState<string>("report1");
  const [isOpen, setIsOpen] = useState<boolean>(true);

  const menu = [
    {
      title: "Reports",
      key: "receivables",
      icon: "pi pi-wallet",
      children: [
        { title: "Receivables Report - 1", key: "report1" },
        { title: "Receivables Report - 2", key: "report2" },
        {
          title: "Sales Tracker",
          key: "salesTracker",
          icon: "pi pi-chart-line",
        },
        { title: "EEFC Tracker", key: "eefcTracker", icon: "pi pi-dollar" },
      ],
    },

    { title: "Invoice", key: "invoice", icon: "pi pi-file-edit" },
    {
      title: "Payment Request",
      key: "paymentRequest",
      icon: "pi pi-credit-card",
    },
    
  ];

  React.useEffect(() => {
    console.log(props, "propspropspropspropsprops");
    console.log(
      props.context.pageContext.user.email,
      "props.context.pageContext.user.email",
    );
    console.log(props,"szdfg")
     console.log(props,"szdfsdfghawsedfgasdfgg")
  }, []);

  return (
    <div
      className={`${styles.sidebar} ${isOpen ? styles.open : styles.closed}`}
    >
      {/* 🔹 Toggle Button */}
      <div className={styles.topRight}>
        <div className={styles.toggleBtn} onClick={() => setIsOpen(!isOpen)}>
          <i
            className={`pi ${isOpen ? "pi-angle-left" : "pi-angle-right"}`}
          ></i>
        </div>
      </div>

      <div>
        <img
          style={{ width: "202px", height: "50px", marginLeft: "20px" }}
          src={require("../../assets/technorucs-logo BLACK (1) 4.png")}
          alt="Logo"
        />
      </div>

      {/* 🔹 Center Navigation */}
      <div className={styles.centerNav}>
        {menu.map((item) => (
          <div key={item.key}>
            <div
              className={`${styles.menuItem} ${
                activeItem === item.key ? styles.active : ""
              }`}
              onClick={() => {
                if (item.children) {
                  setOpenMenu(openMenu === item.key ? null : item.key);
                } else {
                  setActiveItem(item.key);
                }
              }}
            >
              <i className={item.icon}></i>

              {isOpen && <span>{item.title}</span>}

              {item.children && isOpen && (
                <i
                  className={`pi ${
                    openMenu === item.key
                      ? "pi-chevron-down"
                      : "pi-chevron-right"
                  }`}
                ></i>
              )}
            </div>

            {/* Submenu */}
            {item.children && openMenu === item.key && isOpen && (
              <div className={styles.subMenu}>
                {item.children.map((child) => (
                  <div
                    key={child.key}
                    className={`${styles.subItem} ${
                      activeItem === child.key ? styles.activeChild : ""
                    }`}
                    onClick={() => setActiveItem(child.key)}
                  >
                    {child.title}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
      {/* 🔹 Bottom Current User */}
      <div className={styles.bottomUser}>
        <img
          className={styles.userImage}
          src={`/_layouts/15/userphoto.aspx?size=S&username=${props.context.pageContext.user.email}`}
          alt="User"
        />
        {isOpen && (
          <div className={styles.userInfo}>
            <span className={styles.userName}>
              {props.context.pageContext.user.displayName}
            </span>
            {/* <span className={styles.userEmail}>
        {props.context.pageContext.user.email}
      </span> */}
          </div>
        )}
      </div>
    </div>
  );
};

export default SideNav;
