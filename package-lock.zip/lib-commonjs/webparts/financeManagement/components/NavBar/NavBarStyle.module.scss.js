"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require("./NavBarStyle.module.css");
var styles = {
    sideBar: 'sideBar_76fe842f',
    optionContainer: 'optionContainer_76fe842f',
    seletedOptionContainer: 'seletedOptionContainer_76fe842f',
    DrpIcons: 'DrpIcons_76fe842f',
    ul: 'ul_76fe842f',
    ul02: 'ul02_76fe842f',
    seletedMembersContainer: 'seletedMembersContainer_76fe842f',
    optionMembersContainer: 'optionMembersContainer_76fe842f',
    optionIcon: 'optionIcon_76fe842f',
    onlyIcon: 'onlyIcon_76fe842f',
    employeeName: 'employeeName_76fe842f',
    employeeRole: 'employeeRole_76fe842f'
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=NavBarStyle.module.scss.js.map