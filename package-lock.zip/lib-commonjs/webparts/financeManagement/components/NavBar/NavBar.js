"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var NavBarStyle_module_scss_1 = tslib_1.__importDefault(require("./NavBarStyle.module.scss"));
var SideNav = function (props) {
    var _a = (0, react_1.useState)("receivables"), openMenu = _a[0], setOpenMenu = _a[1];
    var _b = (0, react_1.useState)("report1"), activeItem = _b[0], setActiveItem = _b[1];
    var _c = (0, react_1.useState)(true), isOpen = _c[0], setIsOpen = _c[1];
    var menu = [
        {
            title: "Reports",
            key: "receivables",
            icon: "pi pi-wallet",
            children: [
                { title: "Receivables Report - 1", key: "report1" },
                { title: "Receivables Report - 2", key: "report2" },
                {
                    title: "Sales Tracker",
                    key: "salesTracker",
                    icon: "pi pi-chart-line",
                },
                { title: "EEFC Tracker", key: "eefcTracker", icon: "pi pi-dollar" },
            ],
        },
        { title: "Invoice", key: "invoice", icon: "pi pi-file-edit" },
        {
            title: "Payment Request",
            key: "paymentRequest",
            icon: "pi pi-credit-card",
        },
    ];
    React.useEffect(function () {
        console.log(props, "propspropspropspropsprops");
        console.log(props.context.pageContext.user.email, "props.context.pageContext.user.email");
        console.log(props, "szdfg");
        console.log(props, "szdfsdfghawsedfgasdfgg");
    }, []);
    return (React.createElement("div", { className: "".concat(NavBarStyle_module_scss_1.default.sidebar, " ").concat(isOpen ? NavBarStyle_module_scss_1.default.open : NavBarStyle_module_scss_1.default.closed) },
        React.createElement("div", { className: NavBarStyle_module_scss_1.default.topRight },
            React.createElement("div", { className: NavBarStyle_module_scss_1.default.toggleBtn, onClick: function () { return setIsOpen(!isOpen); } },
                React.createElement("i", { className: "pi ".concat(isOpen ? "pi-angle-left" : "pi-angle-right") }))),
        React.createElement("div", null,
            React.createElement("img", { style: { width: "202px", height: "50px", marginLeft: "20px" }, src: require("../../assets/technorucs-logo BLACK (1) 4.png"), alt: "Logo" })),
        React.createElement("div", { className: NavBarStyle_module_scss_1.default.centerNav }, menu.map(function (item) { return (React.createElement("div", { key: item.key },
            React.createElement("div", { className: "".concat(NavBarStyle_module_scss_1.default.menuItem, " ").concat(activeItem === item.key ? NavBarStyle_module_scss_1.default.active : ""), onClick: function () {
                    if (item.children) {
                        setOpenMenu(openMenu === item.key ? null : item.key);
                    }
                    else {
                        setActiveItem(item.key);
                    }
                } },
                React.createElement("i", { className: item.icon }),
                isOpen && React.createElement("span", null, item.title),
                item.children && isOpen && (React.createElement("i", { className: "pi ".concat(openMenu === item.key
                        ? "pi-chevron-down"
                        : "pi-chevron-right") }))),
            item.children && openMenu === item.key && isOpen && (React.createElement("div", { className: NavBarStyle_module_scss_1.default.subMenu }, item.children.map(function (child) { return (React.createElement("div", { key: child.key, className: "".concat(NavBarStyle_module_scss_1.default.subItem, " ").concat(activeItem === child.key ? NavBarStyle_module_scss_1.default.activeChild : ""), onClick: function () { return setActiveItem(child.key); } }, child.title)); }))))); })),
        React.createElement("div", { className: NavBarStyle_module_scss_1.default.bottomUser },
            React.createElement("img", { className: NavBarStyle_module_scss_1.default.userImage, src: "/_layouts/15/userphoto.aspx?size=S&username=".concat(props.context.pageContext.user.email), alt: "User" }),
            isOpen && (React.createElement("div", { className: NavBarStyle_module_scss_1.default.userInfo },
                React.createElement("span", { className: NavBarStyle_module_scss_1.default.userName }, props.context.pageContext.user.displayName))))));
};
exports.default = SideNav;
//# sourceMappingURL=NavBar.js.map