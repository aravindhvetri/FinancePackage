"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
require("../../../../ExternalRef/CSS/Style.css");
var NavBar_1 = tslib_1.__importDefault(require("../NavBar/NavBar"));
var MainComponent = function (props) {
    return React.createElement("div", null,
        React.createElement(React.Fragment, null,
            React.createElement(NavBar_1.default, { context: props.context })));
};
exports.default = MainComponent;
//# sourceMappingURL=MainComponent.js.map