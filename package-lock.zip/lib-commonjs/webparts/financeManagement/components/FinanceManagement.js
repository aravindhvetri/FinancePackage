"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var pnpjs_1 = require("@pnp/pnpjs");
var MainComponent_1 = tslib_1.__importDefault(require("./MainComponents/MainComponent"));
var FinanceManagement = /** @class */ (function (_super) {
    tslib_1.__extends(FinanceManagement, _super);
    function FinanceManagement(prop, state) {
        var _this = _super.call(this, prop) || this;
        pnpjs_1.sp.setup({
            spfxContext: _this.props.context,
        });
        return _this;
    }
    FinanceManagement.prototype.render = function () {
        return (React.createElement("div", null,
            React.createElement(MainComponent_1.default, { context: this.props.context })));
    };
    return FinanceManagement;
}(React.Component));
exports.default = FinanceManagement;
//# sourceMappingURL=FinanceManagement.js.map