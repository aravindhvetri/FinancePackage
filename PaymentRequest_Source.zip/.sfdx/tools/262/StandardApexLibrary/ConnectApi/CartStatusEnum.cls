global enum CartStatusEnum {
}