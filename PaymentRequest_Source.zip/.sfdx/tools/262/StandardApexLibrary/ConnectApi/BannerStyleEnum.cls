global enum BannerStyleEnum {
  Announcement
}