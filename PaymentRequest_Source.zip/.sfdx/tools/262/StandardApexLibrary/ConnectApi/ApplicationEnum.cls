global enum ApplicationEnum {
  RLM
}