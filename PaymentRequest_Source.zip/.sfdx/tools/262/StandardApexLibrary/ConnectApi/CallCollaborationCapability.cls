/**
 * If a feed element has this capability, it has a recording comment.
 */
global class CallCollaborationCapability extends ConnectApi.FeedElementCapability {

  global CallCollaborationCapability() {}

  /**
   * End time of the comment on the media player, in seconds.
   */
  global Integer commentEndTime;

  /**
   * Start time of the comment on the media player, in seconds.
   */
  global Integer commentStartTime;

  global Object clone() {}

}