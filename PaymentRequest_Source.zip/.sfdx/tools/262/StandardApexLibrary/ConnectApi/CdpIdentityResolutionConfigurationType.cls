global enum CdpIdentityResolutionConfigurationType {
}