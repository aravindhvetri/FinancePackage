/**
 * Alternative representation for an extension on a feed element.
 */
global class Alternative {

  global Alternative() {}

  /**
   * Text representation of the extension.
   */
  global String textRepresentation;

  /**
   * Thumbnail URL to the extension.
   */
  global String thumbnailUrl;

  /**
   * Title of the extension.
   */
  global String title;

  global Object clone() {}

}