/**
 * Sends data related to a refund to the payment gateway adapter.
 */
global class RefundRequest {

  global RefundRequest() {}

  /**
   * Maintains the integrity of lists of type RefundRequest by determining the equality of external objects in a list. This method is dynamic and is based on the equals method in Java.
   * @param obj 
   * @return Boolean
   */
  global Boolean equals(Object obj) {}

  /**
   * Maintains the integrity of lists of type RefundRequest by determining the uniqueness of the external object records in a list.
   * @return Integer
   */
  global Integer hashCode() {}

  global Object clone() {}

}