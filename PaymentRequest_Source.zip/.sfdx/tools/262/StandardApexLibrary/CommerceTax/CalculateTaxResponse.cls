/**
 * Sets the values of the tax transaction following a response from the external tax engine. Extends the AbstractTransactionResponse class and is the top-level response class.
 */
global class CalculateTaxResponse {

  global CalculateTaxResponse() {}

  global void setAddresses(commercetax.AddressesResponse addresses) {}

  global void setAmountDetails(commercetax.AmountDetailsResponse amountDetails) {}

  global void setCurrencyIsoCode(String currencyIsoCode) {}

  global void setDescription(String dscptn) {}

  global void setDocumentCode(String documentCode) {}

  global void setEffectiveDate(Datetime effectiveDate) {}

  global void setLineItems(List<commercetax.LineItemResponse> lineItems) {}

  global void setReferenceDocumentCode(String referenceDocumentCode) {}

  global void setReferenceEntityId(String referenceEntityId) {}

  global void setStatus(commercetax.TaxTransactionStatus status) {}

  global void setStatusDescription(String statusDescription) {}

  global void setTaxTransactionId(String taxTrxnId) {}

  global void setTaxTransactionType(commercetax.TaxTransactionType taxTransactionType) {}

  global void setTaxType(commercetax.CalculateTaxType taxType) {}

  global void setTransactionDate(Datetime transactionDate) {}

  global Object clone() {}

  global void setCustomTaxAttributes(commercetax.CustomTaxAttributesResponse customTaxAttributes) {}

}