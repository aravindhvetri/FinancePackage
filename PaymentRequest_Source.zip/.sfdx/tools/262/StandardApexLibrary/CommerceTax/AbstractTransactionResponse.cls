/**
 * Abstract class that contains methods for setting tax fields based on the external tax provider's response. Response classes that extend AbstractTransactionResponse inherit these methods.
 */
global class AbstractTransactionResponse {

  global AbstractTransactionResponse() {}

  global void setAddresses(commercetax.AddressesResponse addresses) {}

  global void setAmountDetails(commercetax.AmountDetailsResponse amountDetails) {}

  global void setCurrencyIsoCode(String currencyIsoCode) {}

  global void setCustomTaxAttributes(commercetax.CustomTaxAttributesResponse customTaxAttributes) {}

  global void setDescription(String dscptn) {}

  global void setDocumentCode(String documentCode) {}

  global void setEffectiveDate(Datetime effectiveDate) {}

  global void setLineItems(List<commercetax.LineItemResponse> lineItems) {}

  global void setReferenceDocumentCode(String referenceDocumentCode) {}

  global void setReferenceEntityId(String referenceEntityId) {}

  global void setTaxTransactionId(String taxTrxnId) {}

  global void setTransactionDate(Datetime transactionDate) {}

  global Object clone() {}

}