/**
 * Contains a Lightning Login eligibility value used by the Auth.SessionManagement.getLightningLoginEligibility method.
 */
global enum LightningLoginEligibility {
  ELIGIBLE,
  ORG_AUTHENTICATOR_NOT_ENABLED,
  ORG_PREF_NOT_ENABLED,
  USER_AUTHENTICATOR_NOT_CONNECTED,
  USER_NOT_ALLOWED,
  USER_NOT_ENROLLED,
  USER_PERM_NOT_ENABLED
}