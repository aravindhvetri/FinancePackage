/**
 * Provides request HTTP headers, body, and query parameters to the AuthProviderPlugin.handleCallback method for user authentication. This class allows you to group the information passed in rather than passing headers, body, and query parameters individually.
 */
global class AuthProviderCallbackState {

  global AuthProviderCallbackState(Map<String,String> headers, String body, Map<String,String> queryParameters) {}

  global String body;

  global Map<String,String> headers;

  global Map<String,String> queryParameters;

  global Object clone() {}

}